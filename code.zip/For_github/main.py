

# Modules for data ingestion from data sources
import json
import pandas as pd
import sqlite3

num_json_records = 0
num_sqlite_table_records = 0
num_csv_records = 0
num_target_records = 0

'''def check_for_new_records_in_table():
    # TODO
'''


'''def check_null_values():
    # TODO
'''


def create_target_data():

    # Connect to the SQLite database
    conn = sqlite3.connect('IPL_Deliveries_lake.db')
    cursor = conn.cursor()

    destination_table = 'Player_stats'

    # Assuming it's a full load everytime
    cursor.execute('DROP TABLE IF EXISTS Player_stats')

    # Create the table (if it doesn't exist)
    create_table_query = '''
    CREATE TABLE IF NOT EXISTS Player_stats (
        player_id INTEGER,
        player_fullname TEXT,
        player_team1 TEXT,
        player_team2 TEXT,
        player_match_season TEXT,
        player_match_date DATE,
        player_match_winner TEXT,
        player_match_win_by_runs INTEGER,
        player_match_win_by_wickets INTEGER,
        player_match_venue TEXT,
        player_of_match TEXT
    )
    '''

    cursor.execute(create_table_query)

    # Execute the SQL query with the join operation
    join_query = '''
    INSERT INTO Player_stats
    SELECT 
    plyrinfo.id,
    plyrinfo."Full name",
    match.team1,
    match.team2,
    match.Season,
    match.date,
    match.winner,
    match.win_by_runs,
    match.win_by_wickets,
    match.venue,
    match.player_of_match
    FROM IPL_matches_lake as match
    JOIN IPL_Players_info_lake as plyrinfo 
    ON match.id = plyrinfo.id
    '''
    cursor.execute(join_query)

    # Commit the transaction
    conn.commit()

    # Execute the SQL query with the join operation
    src_join_query = '''
    SELECT 
    COUNT(*)
    FROM(   SELECT 
            plyrinfo.id,
            plyrinfo."Full name",
            match.team1,
            match.team2,
            match.Season,
            match.date,
            match.winner,
            match.win_by_runs,
            match.win_by_wickets,
            match.venue,
            match.player_of_match
            FROM IPL_matches_lake as match
            JOIN IPL_Players_info_lake as plyrinfo 
            ON match.id = plyrinfo.id) AS JOINQRY
    '''
    cursor.execute(src_join_query)

    # Get the number of records inserted
    global num_target_records
    num_target_records = cursor.rowcount

    # Print the number of records inserted
    print("Number of records inserted:", num_target_records)

    # Commit the transaction
    conn.commit()

    # Close the connection
    conn.close()


def read_csv_data_into_laketable():

    # Create the table in the SQLite database
    '''create_table_query = f"CREATE TABLE IF NOT EXISTS {table_name} (column1 datatype, column2 datatype, ...)"
    cursor.execute(create_table_query)
    '''

    # Connect to the SQLite database
    conn = sqlite3.connect('IPL_Deliveries_lake.db')
    cursor = conn.cursor()

    # Specify the table name
    table_name = 'IPL_Players_info_lake'

    # Read the CSV file using pandas to infer the schema
    #dtypes = {'101': str}  # Specify column 101 as string
    #df = pd.read_csv('Players_info.csv', dtypes=dtypes, low_memory=False)
    df = pd.read_csv('Players_info.csv', low_memory=False)

    # Get the number of records
    global num_csv_records
    num_csv_records = df.shape[0]

    # Print the number of records
    print("Number of source CSV file records: ", num_csv_records)

    # Assuming it's a full load everytime
    cursor.execute('DROP TABLE IF EXISTS IPL_Players_info_lake')

    # Create the table in the SQLite database based on the inferred schema
    df.to_sql(table_name, conn, if_exists='replace', index=False)

    # Commit the changes and close the connection
    conn.commit()
    conn.close()


def read_sqlite_table_into_laketable():
    global num_sqlite_table_records

    conn = sqlite3.connect('IPL_Deliveries.sqlite')
    cur = conn.cursor()

    cur.execute('SELECT COUNT(*) FROM deliveries')
    result = cur.fetchone()
    # Convert the result to an integer
    num_sqlite_table_records = int(result[0])

    # Print the number of records
    print("Number of SQLite Source Table records:", num_sqlite_table_records)

    # Connect to the source SQLite database
    source_conn = sqlite3.connect('IPL_Deliveries.sqlite')
    source_cursor = source_conn.cursor()

    # Connect to the destination SQLite database
    destination_conn = sqlite3.connect('IPL_Deliveries_lake.db')
    destination_cursor = destination_conn.cursor()

    # Specify the source and destination table names
    source_table = 'deliveries'
    destination_table = 'IPL_deliveries_lake'

    # Assuming it's a full load everytime
    destination_cursor.execute('DROP TABLE IF EXISTS IPL_deliveries_lake')

    # Create the table (if it doesn't exist)
    destination_cursor.execute('CREATE TABLE IF NOT EXISTS IPL_deliveries_lake '
                   '(match_id INTEGER,'
                   ' inning INTEGER,'
                   ' batting_team TEXT,'
                   ' bowling_team TEXT,'
                   ' over INTEGER,'
                   ' ball INTEGER,'
                   ' batsman TEXT,'
                   ' non_striker TEXT,'
                   ' bowler TEXT,'
                   ' is_super_over INTEGER,'
                   ' wide_runs INTEGER,'
                   ' bye_runs INTEGER,'
                   ' legbye_runs INTEGER,'
                   ' noball_runs INTEGER,'
                   ' penalty_runs INTEGER,'
                   ' batsman_runs INTEGER,'
                   ' extra_runs INTEGER,'
                   ' total_runs INTEGER,'
                   ' player_dismissed TEXT,'
                   ' dismissal_kind TEXT,'
                   ' fielder TEXT)'
                   '')


    # Select data from the source table
    source_cursor.execute(f"SELECT * FROM {source_table}")
    rows = source_cursor.fetchall()

    # Insert data into the destination table
    for row in rows:
        # Modify the row data as needed
        # For example, if the destination table has different column names or order,
        # you can rearrange or rename the elements of the 'row' tuple

        destination_cursor.execute(f"INSERT INTO {destination_table} VALUES "
                                   f"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", row)

    # Commit the changes and close the connections
    destination_conn.commit()
    destination_conn.close()
    source_conn.close()


def read_json_into_table():

    # Read data from JSON file
    with open('matches.json', 'r') as file:
        json_data = json.load(file)

    # Get the number of records
    global num_json_records
    num_json_records = len(json_data)

    # Print the number of records
    print("Number of source JSON file records:", num_json_records)

    # Connect to the SQLite database
    connection = sqlite3.connect('IPL_Deliveries_lake.db')
    cursor = connection.cursor()

    # Assuming it's a full load everytime
    cursor.execute('DROP TABLE IF EXISTS IPL_matches_lake')

    # Create the table (if it doesn't exist)
    cursor.execute('CREATE TABLE IF NOT EXISTS IPL_matches_lake '
                   '(id INTEGER,'
                   ' Season TEXT,'
                   ' city TEXT,'
                   ' date DATE,'
                   ' team1 TEXT,'
                   ' team2 TEXT,'
                   ' toss_winner TEXT,'
                   ' toss_decision TEXT,'
                   ' result TEXT,'
                   ' dl_applied INTEGER,'
                   ' winner TEXT,'
                   ' win_by_runs INTEGER,'
                   ' win_by_wickets INTEGER,'
                   ' player_of_match TEXT,'
                   ' venue TEXT,'
                   ' umpire1 TEXT,'
                   ' umpire2 TEXT,'
                   ' umpire3 TEXT )'
                   '')

    # Iterate over the JSON data and insert into the SQLite table
    for entry in json_data:
        column1_value = entry['id']
        column2_value = entry['Season']
        column3_value = entry['city']
        column4_value = entry['date']
        column5_value = entry['team1']
        column6_value = entry['team2']
        column7_value = entry['toss_winner']
        column8_value = entry['toss_decision']
        column9_value = entry['result']
        column10_value = entry['dl_applied']
        column11_value = entry['winner']
        column12_value = entry['win_by_runs']
        column13_value = entry['win_by_wickets']
        column14_value = entry['player_of_match']
        column15_value = entry['venue']
        column16_value = entry['umpire1']
        column17_value = entry['umpire2']
        column18_value = entry['umpire3']

        cursor.execute('INSERT INTO IPL_matches_lake '
                       '(id, Season, city, date, team1,'
                       ' team2, toss_winner, toss_decision, result,'
                       ' dl_applied, winner, win_by_runs, win_by_wickets,'
                       ' player_of_match, venue, umpire1, umpire2,'
                       ' umpire3)'
                       'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                       (column1_value, column2_value, column3_value,
                        column4_value, column5_value, column6_value,
                        column7_value, column8_value, column9_value,
                        column10_value, column11_value, column12_value,
                        column13_value, column14_value, column15_value,
                        column16_value, column17_value, column18_value))

        connection.commit() # Too much IO.. Code can be improved?

    '''# Execute a query and retrieve the result
    cursor.execute("SELECT COUNT(*) FROM IPL_matches_lake")
    result = cursor.fetchone()

    # Convert the result to an integer
    count = int(result[0])

    # Print the integer value
    print("Inserted into IPL_matches_lake, count:")
    print(count)
    '''

    # Commit the changes and close the cursor and connection
    cursor.close()
    connection.close()


def explore_table_schema():
    # Connect to the SQLite database
    connection = sqlite3.connect("IPL_Deliveries.sqlite")
    cursor = connection.cursor()

    # Execute PRAGMA statement to retrieve column names
    cursor.execute("PRAGMA table_info(deliveries)")
    columns = cursor.fetchall()

    # Extract column names from the result
    column_names = [column[1] for column in columns]

    # Print the column names
    print("The columns are: ")
    for column_name in column_names:
        print(column_name)

    # Print the column details (schema)
    print("The columns with details are: ")
    for each in columns:
        column_name = each[1]
        column_type = each[2]
        is_nullable = each[3]
        default_value = each[4]
        is_primary_key = each[5]

        print(f"Column Name: {column_name}")
        print(f"Column Type: {column_type}")
        print(f"Is Nullable: {is_nullable}")
        print(f"Default Value: {default_value}")
        print(f"Is Primary Key: {is_primary_key}")
        print("-------------")


    # Close the cursor and connection
    cursor.close()
    connection.close()


def check_for_duplicate_records(sqlite_db='IPL_Deliveries_lake.db', table_name='IPL_matches_lake'):

    try:
        if sqlite_db is not None and table_name is not None:
            conn = sqlite3.connect(sqlite_db) #'IPL_Deliveries_lake.db'
            cur = conn.cursor()

            # Execute a query and retrieve the result
            cur.execute("SELECT "
                        "id,"
                        "Season,"
                        "city,"
                        "date,"
                        "team1,"
                        "team2,"
                        "toss_winner,"
                        "toss_decision,"
                        "result,"
                        "dl_applied,"
                        "winner,"
                        "win_by_runs,"
                        "win_by_wickets,"
                        "player_of_match,"
                        "venue,"
                        "umpire1,"
                        "umpire2,"
                        "umpire3,"
                        "COUNT(*) "
                        "FROM " + str(table_name) +
                        " GROUP BY id,Season,city,date,team1,team2,toss_winner,toss_decision,result,dl_applied,"
                        "         winner,win_by_runs,win_by_wickets,player_of_match,venue,umpire1,umpire2,umpire3 "
                        "HAVING COUNT(*) > 1")

            duplicate_records = cur.fetchall()

            # Print the duplicate records
            if len(duplicate_records) > 0:
                print("Printing duplicate records:")
                for record in duplicate_records:
                    print(record)

            # Close the cursor and connection
            cur.close()
            conn.close()
    except:
        print("Exception in check_for_duplicate_records()")


def data_validation(sql_db=None, table_name=None, to_match_count=0):

    try:
        if sql_db is not None and table_name is not None:

            # Connect to the SQLite database
            conn = sqlite3.connect(sql_db)
            cur = conn.cursor()

            # Execute a query and retrieve the result
            cur.execute("SELECT COUNT(*) FROM " + str(table_name))
            result = cur.fetchone()

            # Convert the result to an integer
            count = int(result[0])

            print("************************** Data validation after ingestion"
                  " into the " + str(table_name) + " table *******************"
                                                   "*******")

            # Print the integer record count
            print("Validation check#1 - Record count check: ")
            print("Number of records ingested into the table: " + str(count) + "\n")

            # Print the result of count comparison between source and destination
            print("Validation check#2 - Record count match check "
                  "between source & destination: ")
            if to_match_count > 0:
                result = "True" if count == to_match_count else "False"
                print("The record count match between source & "
                      "destination is: " + result + "\n")
            else:
                print("No count match comparison between source & destination data done")

        else:
            print("Invalid or no SQLite Database/ table name"
                  " provided as input! Exiting data validation..")
    except:
        print("Exception in data_validation()")
    finally:
        # Close the cursor and connection
        cur.close()
        conn.close()
        print("******************************************** End of table "
              "data validation *****************************************\n")


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print('ORKA DATA ENGINEER CODING CHALLENGE - SOLUTION ..\n')

    # Read SQLite table into Lake DB, table, perform data validation
    read_sqlite_table_into_laketable()
    data_validation('IPL_Deliveries_lake.db', 'IPL_deliveries_lake', num_sqlite_table_records)

    # Read JSON file contents into Lake DB, table, perform data validation
    read_json_into_table()
    data_validation('IPL_Deliveries_lake.db', 'IPL_matches_lake', num_json_records)
    check_for_duplicate_records('IPL_Deliveries_lake.db', 'IPL_matches_lake')

    # Read CSV file data into Lake DB, table, perform data validation
    read_csv_data_into_laketable()
    data_validation('IPL_Deliveries_lake.db', 'IPL_Players_info_lake', num_csv_records)

    # Create the target data model data in the table
    create_target_data()
    data_validation('IPL_Deliveries_lake.db', 'Player_stats', num_target_records)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
